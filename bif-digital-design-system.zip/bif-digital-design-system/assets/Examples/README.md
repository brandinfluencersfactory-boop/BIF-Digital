Reference LinkedIn carousel "Recap B2B" (9 slides, 1080×1350 px), the source for the `CarouselSlide` component and the Social tokens. Slide order: cover, context, stat 71%, insight, stat 26→90%, news 3, what the data does not prove, weekly checklist, closing CTA.

- `carrusel-recap-b2b-bif-v2.pdf`: exported from Chromium; fonts embedded are Space Grotesk, IBM Plex Sans, IBM Plex Mono, Inter.
- Use it for layout and tone only; its news items and figures belong to that post and must not be reused as claims.
