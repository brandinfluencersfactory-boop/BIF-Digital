BIF Digital logo, speech-bubble mark with "BiF". Supplied as PNG renders (3750 × 3975, transparent background) of the master vector files `BIFLogo_black_v3.1` and `BIFLogo_white_v3.1`.

- `bif-logo-dark.png`: charcoal `#333333` ink with yellow `#FFB300`. Use on `surface` (paper/white) grounds.
- `bif-logo-light.png`: light `#EFEFEF` ink with yellow `#FFB300`. Use on `ink` grounds only; it disappears on white.
- Both are multi-color PNGs: ink is baked in, so they cannot be recolored with CSS.
- The master SVGs were not received by this system; add them here as `bif-logo-dark.svg` / `bif-logo-light.svg` when available.
