HazardStripe is the brand divider: a band of `yellow` and `ink` bars at 45°, 12px each (`space-3`), via `repeating-linear-gradient(45deg, yellow 0 12px, ink 12px 24px)`. The footer top uses 14px bars; a 90° 8px variant marks the footer middle.

Consumer provides: the width (full-bleed) and height (10–16px). Use as a divider between sections, never behind text and never more than once per viewport.