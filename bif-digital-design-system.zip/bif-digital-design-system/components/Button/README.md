Button is the square yellow call-to-action: Barlow Condensed 700, uppercase, `yellow` fill with `on-accent` text and no radius.

Consumer provides: the label (an imperative ending in "→") and the ground. Sizes: small (12px 20px, tracking 1.12px), default (15px 32px, 1.4px), large (18px 40px, 15px type, 1.5px). Use one primary per section; secondary actions use the ghost variant with a 2px `text` outline, on `ink` grounds with `#F2F2F2`.

Do: keep corners square. Do not: use `radius-md` (the rounded `.btn-yellow` on the site is legacy), put yellow text on a light ground, or hide the focus ring (3px `text` outline).