BIF Digital is a B2B marketing agency for industry and manufacturing in Mexico. One brand, three channels with their own dialect: the industrial site, the editorial blog and the LinkedIn carousel. Pick the channel first, then use only that channel's type and colors.

| Channel | Display | Body | Labels | Yellow | Ground |
| --- | --- | --- | --- | --- | --- |
| Site (home) | Barlow Condensed 800, UPPERCASE | IBM Plex Sans | JetBrains Mono | `yellow` #F5C400 | `ink` / `surface` |
| Blog | Bricolage Grotesque 800, sentence case | Inter | JetBrains Mono | `yellow` #F5C402 (`--yellow`) | `ink-warm` / `blog-surface` |
| LinkedIn carousel | Space Grotesk 500–700, sentence case | IBM Plex Sans | IBM Plex Mono | `social-yellow` #F9B100 | `social-ink` / `social-paper` |

The logo mark is yellow #FFB300 (`yellow-logo`). Four yellows exist in the sources; do not unify them silently, and never recolor the logo to match.

## Content fundamentals

- Speak in first-person plural or direct "tú", confident and concrete, to an industrial or B2B executive. Real copy: "Convertimos directivos en referentes de su industria.", "El marketing industrial no falla. Falla cómo lo están haciendo.", "Tu comprador ya decidió antes de escribirte.".
- Write in Spanish (Mexico). On the site headlines are UPPERCASE through styling only; on blog and carousel they are plain sentence case.
- Emphasize ONE word or term per headline: `yellow` on dark site grounds and in blog titles (upright, not italic; italics are only for jargon inside body copy). Carousels do not emphasize inside a headline.
- Buttons are imperatives ending in an arrow: "Hablemos de tu empresa →", "Agendar diagnóstico gratuito →", "Comenta tu respuesta →".
- Be honest about evidence. Carousels cite the source and date under every stat and add a "what this does not prove" slide; state that a figure comes from one company or from sponsored content when it does.
- No emoji in the site or carousel UI. The blog uses one emoji in its eyebrow and CTA labels (e.g. "Intrainfluencer · 12 min de lectura"); keep that to eyebrows and CTA labels only.

## Visual foundations

- Site: alternate `ink` sections with `surface` paper sections and one full-bleed `yellow` section. `yellow` is always paired with `on-accent`. Use `status-gap` and `yellow-dk` as text on dark grounds only. Square corners (`radius-none`) on buttons and cards; `radius-sm` only on eyebrow pills. Hazard stripes (45°, `yellow`/`ink`, 12px bars) divide sections; never behind text. Borders, not shadows. Motion `cubic-bezier(.23,1,.32,1)`.
- Blog: page on `blog-surface`, text `ink-warm`, hero on `ink-warm`. Titles in `post-title`/`post-h2`; eyebrow pill (`eyebrow` in `yellow` on a 12% yellow wash, `radius-sm`) above the title; byline row with author photo, date, reading time (`post-meta`). Open every article with the AnswerBox (direct definition), use italic statistics with a source credit as pull quotes, one MidCta card mid-article and a closing CTA with trust bullets. Buttons here are `radius-md` (10px) in sentence case: the blog and site buttons differ on purpose.
- Carousel: 1080×1350 (4:5), 88px margin (`slide-margin`). Sequence ink cover, paper, yellow stat, ink, yellow stat, paper, paper list, paper checklist, ink CTA. Every slide carries a mono page counter ("03 / 09") top-left and a slide kind top-right (`slide-meta`); the cover and CTA slides carry the light logo (80×84 at 88,96) instead. Cover and closing slides end with a mono footer ("BIF Digital" / "Desliza →" / "bif.digital"). A 119×8 `social-yellow` bar sits above the cover title and 88×8 at the foot of paper slides. Stats are one huge Space Grotesk 700 number in `social-ink` on yellow with a source line above a 3px rule. Lists use 3px `social-ink` rules; checklist cards are white with a 1.5px `social-rule` outline and a 68px `social-ink` circle holding a `social-yellow` numeral. The closing button is a square `social-yellow` rectangle (559×108) with `social-ink` text.
- Fonts load from Google Fonts: Barlow Condensed 700/800; Bricolage Grotesque 800; Space Grotesk 500/600/700; Inter 400/600/700; IBM Plex Sans 400/500/600; IBM Plex Mono 400/500; JetBrains Mono 400/700.

## Logo

The mark is a speech bubble containing "BiF" with two yellow squares. Place `assets/Logos/bif-logo-dark.png` on light grounds and `assets/Logos/bif-logo-light.png` on dark grounds. Never recolor, outline, rotate or crop it; keep clear space of at least one bubble-stroke width.

## Components

Site: `Button`, `Eyebrow`, `Headline`, `HazardStripe`. Blog: `AnswerBox`, `MidCta`. Social: `CarouselSlide`. Each has a live preview. Consumers provide the text, the ground and the Google Fonts links. `assets/Examples/` holds the reference LinkedIn carousel PDF. `assets/Templates/` holds every editable template and graphic proposal made for BIF; add new ones there.

## Iconography

None measured on any channel. Use the typographic arrow "→" in buttons and footers; no decorative icons.
